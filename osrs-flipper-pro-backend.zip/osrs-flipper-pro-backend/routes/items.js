const express = require("express");
const router = express.Router();
const db = require("../db/db");
const selectColumns = require("../queries/selectColumns");
const buildFilters = require("../queries/buildFilters");
const buildJoins = require("../queries/buildJoins");

// GET /api/items/latest-table
router.get("/latest-table", async (req, res) => {
    try {
        // Destructure and normalize query params
        const {
            page = 1,
            pageSize = 50,
            sortBy = "margin",
            order = "desc",
            search,
            columns,
            ...queryFilters
        } = req.query;

        const pageNum = Math.max(parseInt(page, 10), 1);
        const limit = Math.max(parseInt(pageSize, 10), 1);
        const offset = (pageNum - 1) * limit;

        // Validate sort column against allowed set
        const validSorts = new Set([
            "margin", "roi", "spread",
            "buy_price", "sell_price", "buy_time", "sell_time",
            "max_profit", "max_investment",
            "limit", "limit_x_buy_price",
            // volume
            "volume_5m", "volume_1h", "volume_6h", "volume_24h", "volume_7d",
            // trend
            "trend_5m", "trend_1h", "trend_6h", "trend_24h", "trend_7d", "trend_1m",
            // turnover
            "turnover_5m", "turnover_1h", "turnover_6h", "turnover_24h", "turnover_7d", "turnover_1m",
            // buy/sell rate
            "buy_sell_rate_5m", "buy_sell_rate_1h", "buy_sell_rate_6h", "buy_sell_rate_24h", "buy_sell_rate_7d"
        ]);

        const sortColumnMap = {
            buy_price: "low.price",
            sell_price: "high.price",
            buy_time: "low.timestamp",
            sell_time: "high.timestamp",
            limit: "i.limit",
            limit_x_buy_price: "COALESCE(i.limit, 0) * COALESCE(low.price, 0)"
        };

        const resolvedSort = validSorts.has(sortBy)
            ? (sortColumnMap[sortBy] || sortBy)
            : "margin";

        const sortOrder = order.toLowerCase() === "asc" ? "ASC" : "DESC";
        const nullsPosition = "NULLS LAST";

        // Parse requested columns list
        const requestedColumns = typeof columns === "string"
            ? columns.split(",").map(c => c.trim()).filter(Boolean)
            : [];

        // Build filters clause and parameter list
        const { filters, params, paramIndex } = buildFilters({ search, ...queryFilters });

        // Build dynamic JOINs (volume, trend, etc.) based on requestedColumns and queryFilters
        const joins = buildJoins(requestedColumns, queryFilters, sortBy);

        // Build SELECT list for requested columns
        const { select } = selectColumns(requestedColumns);

        // Append pagination params
        params.push(limit, offset);

        // Main data query
        const dataSql = `
      SELECT ${select}
      FROM items i
      ${joins}
      WHERE ${filters}
      ORDER BY ${resolvedSort} ${sortOrder} ${nullsPosition}
      LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`;

        // Count query for pagination
        const countSql = `
      SELECT COUNT(*) AS total
      FROM items i
      ${joins}
      WHERE ${filters}`;

        // Debug logging
        console.log("\n===== COUNT QUERY =====");
        console.log(countSql);
        console.log("COUNT PARAMS:", params.slice(0, -2));

        console.log("\n===== MAIN QUERY =====");
        console.log("Requested Columns:", requestedColumns);
        console.log(dataSql);
        console.log("MAIN PARAMS:", params);

        // Execute queries
        const countResult = await db.query(countSql, params.slice(0, -2));
        const totalRows = parseInt(countResult.rows[0].total, 10);
        const totalPages = Math.ceil(totalRows / limit);

        const dataResult = await db.query(dataSql, params);

        res.json({ items: dataResult.rows, totalPages });

    } catch (err) {
        console.error("DB ERROR:", err);
        res.status(500).json({
            error: "Failed to fetch data",
            detail: err.message
        });
    }
});

module.exports = router;
