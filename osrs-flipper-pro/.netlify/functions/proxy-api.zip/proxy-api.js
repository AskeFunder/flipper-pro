/**
 * Netlify Function to proxy API requests to backend
 * Adds X-FLIPPER-SECRET header from environment variable
 * Uses native Node.js http module for reliability
 */

const http = require('http');
const { URL } = require('url');

exports.handler = async (event, context) => {
    // Netlify Functions use different env var names - try both
    // Temporarily hardcode for testing
    const secret = process.env.REACT_APP_FLIPPER_SECRET || process.env.FLIPPER_API_SECRET || 'ab325c11d3cf87a5eae5eedf1ac6e420c32bb221afcbdddc6a0f7dbc91bb4c3a';
    const backendUrl = 'http://46.101.101.26:3001';
    
    // Extract the API path from the redirect
    const apiPath = event.path.replace('/.netlify/functions/proxy-api', '');
    const queryString = event.rawQuery ? `?${event.rawQuery}` : '';
    const fullUrl = `${backendUrl}${apiPath}${queryString}`;
    const url = new URL(fullUrl);
    
    console.log(`[PROXY] Path: ${event.path}, API Path: ${apiPath}, Full URL: ${fullUrl}`);
    console.log(`[PROXY] Secret present: ${secret ? 'YES' : 'NO'}, Length: ${secret.length}`);
    
    return new Promise((resolve, reject) => {
        const options = {
            hostname: url.hostname,
            port: url.port || 3001,
            path: url.pathname + url.search,
            method: event.httpMethod,
            headers: {
                'Content-Type': 'application/json',
                'X-FLIPPER-SECRET': secret,
            },
        };
        
        console.log(`[PROXY] Request options:`, JSON.stringify(options, null, 2));
        
        const req = http.request(options, (res) => {
            let data = '';
            
            res.on('data', (chunk) => {
                data += chunk;
            });
            
            res.on('end', () => {
                console.log(`[PROXY] Response status: ${res.statusCode}`);
                resolve({
                    statusCode: res.statusCode,
                    headers: {
                        'Content-Type': res.headers['content-type'] || 'application/json',
                        'Access-Control-Allow-Origin': '*',
                    },
                    body: data,
                });
            });
        });
        
        req.on('error', (error) => {
            console.error('[PROXY] Error:', error);
            reject({
                statusCode: 500,
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ error: error.message }),
            });
        });
        
        if (event.httpMethod !== 'GET' && event.body) {
            req.write(event.body);
        }
        
        req.end();
    });
};

